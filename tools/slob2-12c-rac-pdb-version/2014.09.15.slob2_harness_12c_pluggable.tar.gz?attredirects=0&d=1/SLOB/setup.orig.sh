#!/bin/bash
# DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
# The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
# all warranties of any kind, either express or implied, as to the software, including, but not limited to,
# implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
# rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
# any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
# circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
# consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
# user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
# from the use or misuse of the software (including such damages incurred by third parties), or errors of
# the software.                         

function test_conn() {
local ret=""
local connect_string="$1" 

sqlplus -L "$connect_string" <<EOF > .test_conn.out 2>&1
SHOW PARAMETER db_name;
EXIT;
EOF

ret=$?
return $ret
}

function grant() {
local user=$1

sqlplus -s "$CONNECT_STRING" <<EOF
SET ECHO ON
DROP USER $user CASCADE;
GRANT CONNECT TO $user IDENTIFIED BY $user;
GRANT DBA TO $user;
EXIT;
EOF

echo "DROP USER $user CASCADE;" >> drop_users.sql

}

function cr_seed () {

grant user0 > /dev/null 2>&1 

echo "NOTIFY: Creating and loading seed table."


sqlplus -s user0/user0${NON_ADMIN_CONNECT_STRING} <<EOF
SET ECHO ON

CREATE TABLE seed
(
custid NUMBER(8),
c2 VARCHAR2(128),
c3 VARCHAR2(128) ,
c4 VARCHAR2(128) ,
c5 VARCHAR2(128) ,
c6 VARCHAR2(128) ,
c7 VARCHAR2(128) ,
c8 VARCHAR2(128) ,
c9 VARCHAR2(128) ,
c10 VARCHAR2(128) ,
c11 VARCHAR2(128) ,
c12 VARCHAR2(128) ,
c13 VARCHAR2(128) ,
c14 VARCHAR2(128) ,
c15 VARCHAR2(128) ,
c16 VARCHAR2(128) ,
c17 VARCHAR2(128) ,
c18 VARCHAR2(128) ,
c19 VARCHAR2(128) ,
c20 VARCHAR2(128) 
) PARALLEL CACHE PCTFREE 0 tablespace $TABLESPACE;

DECLARE 
nrows	NUMBER := 1;
x	PLS_INTEGER := 0;
fluff	VARCHAR2(128) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';

BEGIN
FOR i IN 1 .. ${SCALE} LOOP

	INSERT INTO seed VALUES (nrows, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff, fluff);
	nrows := nrows + 1;

	x := MOD( nrows, 9973 );

	IF ( x = 0 ) THEN
		COMMIT;
 	END IF;
	
END LOOP;
COMMIT;
END;
/
EXIT;

EOF

echo ""
echo "NOTIFY: Seed table loading procedure has exited."
}

function drop_table() {
local user=$1
local pass=$2

sqlplus -s ${user}/${pass}${NON_ADMIN_CONNECT_STRING} <<EOF
SET ECHO ON
DROP TABLE cf1 PURGE;
EXIT;
EOF
}

function drop_seed_table() {
sqlplus -s user0/user0${NON_ADMIN_CONNECT_STRING} <<EOF
SET ECHO ON
DROP TABLE seed PURGE;
EXIT;
EOF
}


function cr_tab_and_load() {
local user=$1
local pass=$2


sqlplus -s ${user}/${pass}${NON_ADMIN_CONNECT_STRING} <<EOF
SET ECHO ON

CREATE TABLE cf1
(
custid NUMBER(8),
c2 VARCHAR2(128),
c3 VARCHAR2(128) ,
c4 VARCHAR2(128) ,
c5 VARCHAR2(128) ,
c6 VARCHAR2(128) ,
c7 VARCHAR2(128) ,
c8 VARCHAR2(128) ,
c9 VARCHAR2(128) ,
c10 VARCHAR2(128) ,
c11 VARCHAR2(128) ,
c12 VARCHAR2(128) ,
c13 VARCHAR2(128) ,
c14 VARCHAR2(128) ,
c15 VARCHAR2(128) ,
c16 VARCHAR2(128) ,
c17 VARCHAR2(128) ,
c18 VARCHAR2(128) ,
c19 VARCHAR2(128) ,
c20 VARCHAR2(128) 
) NOPARALLEL CACHE PCTFREE 99 TABLESPACE $TABLESPACE 
STORAGE 
(BUFFER_POOL RECYCLE INITIAL 1M NEXT 32K MAXEXTENTS UNLIMITED);

INSERT INTO cf1 SELECT * FROM user0.seed WHERE ROWNUM = 1 ;
COMMIT;

ALTER TABLE cf1 MINIMIZE RECORDS_PER_BLOCK;
TRUNCATE TABLE cf1 ;
COMMIT;

INSERT /*+ PARALLEL APPEND */ INTO cf1 SELECT * FROM user0.seed ORDER BY DBMS_RANDOM.VALUE();
COMMIT;

CREATE UNIQUE INDEX I_CF1 ON cf1(custid) NOPARALLEL PCTFREE 0 TABLESPACE $TABLESPACE;

ALTER INDEX i_cf1 SHRINK SPACE COMPACT;

EXEC DBMS_STATS.GATHER_TABLE_STATS('$user', 'cf1', estimate_percent=>100, block_sample=>TRUE, degree=>2);

EXIT;
EOF
}

function doit() {
local user=$1
local pass=$2

drop_table $user $pass  >> drop_table.out 2>&1
cr_tab_and_load $user $pass >> cr_tab_and_load.out 2>&1
}

function test_sqlplus () {

if ( ! type sqlplus > /dev/null 2>&1 )
then
	echo "FATAL: Please validate your environment. SQL*Plus is not executable in current \$PATH"
	return 1
fi

return 0
}

function check_bom() {
local file=""

if [ ! -f ./misc/BOM ]
then
	echo "FATAL: ${0}: ${FUNCNAME}: No BOM file in ./misc. Incorrect SLOB file contents."
	return 1
fi

for file in `cat ./misc/BOM | xargs echo`
do
	if [ ! -f "$file" ]
	then
		echo "FATAL: ${0}: ${FUNCNAME}: Missing ${file}. Incorrect SLOB file contents."
		return 1
	fi
done

return 0

}


#---------- Main body

if ( ! check_bom )
then
	exit 1
fi

if ( ! test_sqlplus )
then
	echo "FATAL: Cannot proceed in current environment."
	exit 1
fi


export TABLESPACE="$1"

if [ -z "$1" ] 
then
	echo "FATAL: ${0} args"
	echo "Usage : ${0}: <tablespace name> <optional: number of users>" 
	exit 1
fi

MAXUSER=`echo "$2" 2>&1 | sed 's/[^0-9]//g' 2> /dev/null`

if [ -z "$MAXUSER" ]
then
	MAXUSER=128		
fi

if [[ "$MAXUSER" -le 0 || "$MAXUSER" -gt 128 ]] 
then
	echo "FATAL: Must be non-zero and tested maximum is 128."
	echo "Usage : ${0}: <tablespace name> <optional: number of users>"
	exit 1
fi

LOAD_PARALLEL_DEGREE=${LOAD_PARALLEL_DEGREE:=1}
SCALE=${SCALE:=10000}
SQLNET_SERVICE_BASE=${SQLNET_BASE:=''}
SQLNET_SERVICE_MAX=${SQLNET_SERVICE_MAX:=''}
ADMIN_SQLNET_SERVICE=${ADMIN_SQLNET_CONNECT:=''}
SYSDBA_PASSWD=${SYSDBA_PASSWD:=''}
export NON_ADMIN_CONNECT_STRING=""
export CONNECT_STRING=""

source ./slob.conf

rm -f  grant.out drop_table.out  cr_tab_and_load.out drop_users.sql .test_conn.out

if [ -n "$ADMIN_SQLNET_SERVICE" ]
then
	export CONNECT_STRING="sys/${SYSDBA_PASSWD}@${ADMIN_SQLNET_SERVICE} as sysdba"
	export NON_ADMIN_CONNECT_STRING="@${ADMIN_SQLNET_SERVICE}"
	
else
	export CONNECT_STRING="/ as sysdba"
fi


echo "
NOTIFY: Load Parameters (slob.conf): 

LOAD_PARALLEL_DEGREE == $LOAD_PARALLEL_DEGREE
SCALE == $SCALE
ADMIN_SQLNET_SERVICE == \"$ADMIN_SQLNET_SERVICE\"
CONNECT_STRING == \"$CONNECT_STRING\"
NON_ADMIN_CONNECT_STRING == $NON_ADMIN_CONNECT_STRING
"

echo "NOTIFY: Testing connectivity to the instance to validate slob.conf settings."

if ( ! test_conn "$CONNECT_STRING" )
then

		
	echo "FATAL: ${0}: cannot connect to the instance."
	echo "FATAL: Error Output:"
	echo ""
	cat .test_conn.out 2>&1
	echo ""
	echo "FATAL: Please verify the instance is running and the settings"
	echo "FATAL: in slob.conf are correct for your connectivity model."

	exit 1
else

	echo "NOTIFY: ${0}: Successful test connection: \"sqlplus -L $CONNECT_STRING\""
	echo ""
	rm -f  .test_conn.out
fi



USER=""
PASS=""

cr_seed

cnt=1
x=0

echo -ne "NOTIFY: Setting up user  \c"
while [ $cnt -le $MAXUSER ]
do
	echo -ne " $cnt \c"
	USER=user$cnt
	PASS=user$cnt

	(  grant $USER >> grant.out 2>&1 ; doit $USER $PASS ) &

	if [ $x -eq $(( LOAD_PARALLEL_DEGREE - 1 ))  ] 
	then

		echo ""
		echo "NOTIFY: Waiting for background processes - `date`"  
		wait 
		[[ $cnt -ne $MAXUSER ]] && echo -ne "NOTIFY: Setting up user  \c"
		x=0
	else
		(( x = $x + 1 ))
	fi
		(( cnt = $cnt + 1 ))

done
wait
echo ""

doit user0 user0
drop_seed_table
wait

echo "NOTIFY: ${0}: Loading procedure complete (${SECONDS} seconds). Please check ./cr_tab_and_load.out for any errors"
echo ""
