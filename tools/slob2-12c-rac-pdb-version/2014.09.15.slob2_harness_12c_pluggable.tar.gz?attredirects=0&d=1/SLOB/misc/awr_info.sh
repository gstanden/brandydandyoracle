#!/bin/bash 
# DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
# The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
# all warranties of any kind, either express or implied, as to the software, including, but not limited to,
# implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
# rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
# any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
# circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
# consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
# user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
# from the use or misuse of the software (including such damages incurred by third parties), or errors of
# the software.                         

function print_int() {
awk '{ printf("%d\n",$1 ) }'
}

function del_cr() {
tr -d '\r'
}

function prep_file() {
local infile=$1
local outfile=$2

cat $infile | del_cr | commas | sed '/^---/d' > $outfile
}

function instance_activity_tuples() {
local fname=$1

cat $fname |  sed -n '/Instance Activity Stats/,$p'
}

function commas() { 
sed 's/\,//g' 
}

function chomp() {
#set -x
local field="$1"

if [ -z "$field" ]
then
	sed -e 's/[a-zA-Z:]//g'
	return
else

	case "$field" in
		"1") sed -e 's/[a-zA-Z:]//g' | awk '{ print $1 }';;
		"2") sed -e 's/[a-zA-Z:]//g' | awk '{ print $2 }';;
		*) echo ;;
	esac
fi

return

}

function f2() {
awk '{ print $2 }'
}

function f1() {
awk '{ print $1 }'
}

function dfsr() {
local f=$1

grep 'db file sequential read' $f | head -1  | chomp | awk '{ 
printf("%6.0lf\n", ( $2 / $1 ) * 10^6  )
}'
}

function dpr() {
local f=$1

grep '^direct path read' $f | head -1 | chomp | awk '{ 
if ( $1 > 100 )
printf("%6.0lf\n", ( $2 / $1 ) * 10^6  )
}'
}

function dfpr() {
local f=$1

grep '^db file parallel read' $f | head -1 | chomp | awk '{ 
if ( $1 > 100 )
printf("%6.0lf\n", ( $2 / $1 ) * 10^6  )
}'
}

function get_read_mbs() {
local f=$1

grep '^physical read total bytes' $f | head -1 | chomp | awk '{ 
printf("%6.0lf\n",  ( $2 / 2 ^ 20)   )
}'
}

function get_write_mbs() {
local f=$1

grep '^physical write total bytes' $f | head -1 | chomp | awk '{ 
printf("%6.0lf\n",  ( $2 / 2 ^ 20)   )
}'
}

function dfpw() {
local f=$1
grep 'db file parallel write' $f | head -1 | chomp | awk '{ 
printf("%6.0lf\n", ( $3 / $1 ) * 10^6 )
}'
}

function lfpw() {
local f=$1
grep 'log file parallel write' $f | head -1 | chomp | awk '{
printf("%6.0lf\n", ( $3 / $1 ) * 10^6 )
}'
}

function get_sesscnt_from_fname() {
local tmp="$1"

#echo "$tmp" | awk ' BEGIN { FS="." } { print $(NF -1 ),"|", $NF }'
echo "$tmp" | awk ' BEGIN { FS="." } { print $NF }'
}

function get_top_event() {
local f=$1
local outstring=""

outstring=`cat $f | sed -n '/Top 5 Timed/,/Host CPU/p' | sed -n -e '/^Event/{n;p;}' `
echo $outstring
}


function get_runtime() {
local f=$1
local x=""

grep 'Elapsed:' $f | awk '{ printf("%d\n", $2 * 60 ) }'
}

function get_redo_mbs () {
local f=$1
local x=""

x=`grep 'Redo size:' $f | chomp 1`
echo "scale=1 ; $x / 2^20" | bc -q
}

function get_exec_per_second () {
local f=$1
local x=""

x=`grep 'Executes:' $f | chomp 1 | print_int `
echo $x
}

#------

tmpfile=.${$}${RANDOM}
origfile=""

echo "FILE|SESSIONS|ELAPSED|EXECUTES|PREADS|READ_MBS|PWRITES|WRITE_MBS|REDO_MBS|DFSR_LAT|DPR_LAT|DFPR_LAT|DFPW_LAT|LFPW_LAT|TOP WAIT|"

for file in $*
do
#dfsr_lat=0 ; dpr_lat=0 ; dfpw_lat=0 ; lfpw_lat=0


	origfile=$file
	num_sessions=`get_sesscnt_from_fname $origfile`
	prep_file $origfile $tmpfile
	file=$tmpfile

	elapsed=`get_runtime $file`

	top_event=`get_top_event $file`
	pwrites=`instance_activity_tuples $file | sed -n '/^physical writes/{p;q;}' | chomp 2 | print_int `
	preads=`instance_activity_tuples $file | sed -n '/^physical reads/{p;q;}' | chomp 2 | print_int `
	read_mbs=`get_read_mbs $file`
	write_mbs=`get_write_mbs $file`

	redo_mbs=`get_redo_mbs $file`
	executes=`get_exec_per_second $file`


	dfsr_lat=`dfsr $file `
	dpr_lat=`dpr $file`
	dfpr_lat=`dfpr $file`
	dfpw_lat=`dfpw $file`
	lfpw_lat=`lfpw $file`
	echo "$origfile|$num_sessions|$elapsed|$executes|$preads|$read_mbs|$pwrites|$write_mbs|$redo_mbs|$dfsr_lat|$dpr_lat|$dfpr_lat|$dfpw_lat|$lfpw_lat|$top_event|"
done 

rm -f $tmpfile
