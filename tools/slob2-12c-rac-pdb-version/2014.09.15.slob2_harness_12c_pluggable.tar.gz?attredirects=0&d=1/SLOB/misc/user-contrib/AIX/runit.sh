#!/bin/ksh
# DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
# The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
# all warranties of any kind, either express or implied, as to the software, including, but not limited to,
# implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
# rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
# any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
# circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
# consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
# user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
# from the use or misuse of the software (including such damages incurred by third parties), or errors of
# the software.                         

if [ -z "$2" ]
then

	echo "${0}: Usage : ${0} <number of write threads> <number of read threads>"
	exit
else

	WU=$1
	RU=$2
fi



./create_sem > /dev/null 2>&1

cnt=1
until [ $cnt -gt $RU ]
do
	( sqlplus -s user${cnt}/user${cnt} @reader > /dev/null 2>&1 ) &
	(( cnt = $cnt + 1 ))
done

until [ $cnt -gt $(( WU + RU )) ]
do
	( sqlplus -s user${cnt}/user${cnt} @writer > /dev/null 2>&1 ) &
	(( cnt = $cnt + 1 ))
done
		

sleep 10 

sqlplus -L '/as sysdba'  @awr/awr_snap > /dev/null

B=$SECONDS
./trigger > /dev/null 2>&1

wait

(( TM =  $SECONDS - $B ))

echo "Tm $TM"

sqlplus -L '/as sysdba'  @awr/awr_snap > /dev/null
sqlplus -L '/as sysdba'  @awr/create_awr_report > /dev/null


