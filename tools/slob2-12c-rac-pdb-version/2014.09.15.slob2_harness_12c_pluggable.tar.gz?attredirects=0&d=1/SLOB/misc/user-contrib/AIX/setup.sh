#!/bin/sh
# DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
# The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
# all warranties of any kind, either express or implied, as to the software, including, but not limited to,
# implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
# rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
# any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
# circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
# consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
# user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
# from the use or misuse of the software (including such damages incurred by third parties), or errors of
# the software.                         

grant()
{
local user=$1
sqlplus -s '/ as sysdba'  <<EOF
set echo on
DROP USER $user CASCADE;
grant connect to $user identified by $user;
grant dba to $user;
exit;
EOF

echo "DROP USER $user CASCADE;" >> drop_users.sql

}

 cr_seed () {

sqlplus -s user1/user1 <<EOF
set echo on

CREATE TABLE seed
(
custid number(8),
c2 varchar2(128),
c3 varchar2(128),
c4 varchar2(128),
c5 varchar2(128),
c6 varchar2(128),
c7 varchar2(128),
c8 varchar2(128),
c9 varchar2(128),
c10 varchar2(128),
c11 varchar2(128),
c12 varchar2(128),
c13 varchar2(128),
c14 varchar2(128),
c15 varchar2(128),
c16 varchar2(128),
c17 varchar2(128),
c18 varchar2(128),
c19 varchar2(128),
c20 varchar2(128)
) PARALLEL PCTFREE 0 tablespace $TABLESPACE;

DECLARE 
x      NUMBER :=1;
fluff  varchar2(128) := 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';

BEGIN
FOR i IN 1..10000 LOOP
	insert into seed values (x,fluff, NULL, NULL, NULL, NULL, 
        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, fluff);
	x := x + 1;

END LOOP;
COMMIT;
END;
/
exit;

EOF
}

drop_table() {
 user=$1
 pass=$2

sqlplus -s $user/$pass <<EOF
set echo on
drop table cf1;
exit;
EOF
}


 cr_tab_and_load() {
local user=$1
local pass=$2


sqlplus -s $user/$pass <<EOF
set echo on
REM alter session force parallel DML;

CREATE TABLE cf1
(
custid number(8),
c2 varchar2(128),
c3 varchar2(128),
c4 varchar2(128),
c5 varchar2(128),
c6 varchar2(128),
c7 varchar2(128),
c8 varchar2(128),
c9 varchar2(128),
c10 varchar2(128),
c11 varchar2(128),
c12 varchar2(128),
c13 varchar2(128),
c14 varchar2(128),
c15 varchar2(128),
c16 varchar2(128),
c17 varchar2(128),
c18 varchar2(128),
c19 varchar2(128),
c20 varchar2(128)
) NOPARALLEL PCTFREE 99 tablespace $TABLESPACE storage 
(buffer_pool recycle INITIAL 1M NEXT 32K MAXEXTENTS UNLIMITED);

insert into cf1 select * from user1.seed where rownum = 1 ;
commit;

alter table cf1 minimize records_per_block;
truncate table cf1 ;
commit;

insert /*+ APPEND */ into cf1 select * from user1.seed order by  dbms_random.value();
commit;

create unique index i_cf1 on cf1(custid) NOPARALLEL PCTFREE 0 tablespace $TABLESPACE;

alter index i_cf1 SHRINK SPACE COMPACT;

exec DBMS_STATS.GATHER_TABLE_STATS('$user', 'cf1', estimate_percent=>100, block_sample=>TRUE, degree=>2);

exit;
EOF
}

 doit() {
local user=$1
local pass=$2


if [ "$user" = "user1" ] 
then
	cr_seed
fi

drop_table $user $pass  >> drop_table.out 2>&1
cr_tab_and_load $user $pass >> cr_tab_and_load.out 2>&1
}


# Main script body

rm -f  grant.out drop_table.out  cr_tab_and_load.out drop_users.sql

export TABLESPACE="$1"

[[ -z "$1" ]] && echo "Usage : ${0}: <tablespace name> <optional: number of users>" && exit 127


USER=""
PASS=""

cnt=1
[[ ! -z "$2" ]] && MAX=$2 || MAX=128


until [ $cnt -gt $MAX ]
do
	echo "Setting up user $cnt"
	USER=user$cnt
	PASS=user$cnt

	grant $USER >> grant.out 2>&1

	( doit $USER $PASS ) &

	(( x = cnt % 1 ))
	[[ $x -eq 0 ]]  && echo "Waiting for background processes - `date`" && wait
	(( cnt = $cnt + 1 ))

done


wait

