-- DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
-- The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
-- all warranties of any kind, either express or implied, as to the software, including, but not limited to,
-- implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
-- rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
-- any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
-- circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
-- consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
-- user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
-- from the use or misuse of the software (including such damages incurred by third parties), or errors of
-- the software.                   

spool createDB.lis
startup force exclusive nomount pfile=./create.ora


create database SLOB CONTROLFILE REUSE
SET DEFAULT BIGFILE TABLESPACE
maxinstances 1
maxdatafiles 1024
maxlogfiles 16
noarchivelog
datafile size 50M
logfile SIZE 4G, SIZE 4G, SIZE 4G 
/

alter tablespace SYSTEM autoextend on;
alter tablespace SYSAUX autoextend on;
set echo off

@?/rdbms/admin/catalog
@?/rdbms/admin/catproc

connect / as sysdba 

@?/sqlplus/admin/pupbld

create BIGFILE tablespace IOPS datafile size 1G NOLOGGING ONLINE 
PERMANENT EXTENT MANAGEMENT LOCAL AUTOALLOCATE  SEGMENT SPACE MANAGEMENT AUTO ;

REM -> 2013.02.01 : Fixed the following alter tablespace from tablespace SLOB to IOPS

alter tablespace IOPS autoextend on next 200m maxsize unlimited;
