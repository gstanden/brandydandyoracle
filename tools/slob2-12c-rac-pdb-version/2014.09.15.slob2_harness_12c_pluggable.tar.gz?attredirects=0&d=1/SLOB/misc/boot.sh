#!/bin/bash
# DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
# The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
# all warranties of any kind, either express or implied, as to the software, including, but not limited to,
# implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
# rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
# any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
# circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
# consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
# user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
# from the use or misuse of the software (including such damages incurred by third parties), or errors of
# the software.                         


if [ -z "$1" ]
then
	echo "Usage: ${0}: Script requires a single argument for init.ora file path"
	exit 1
else

	if [ ! -f "$1" ]
	then
		echo "FATAL: ${0}: \"$1\" no such file." 
		exit 1 
	fi

fi


export ADMIN_CONNECT_STRING="/ as sysdba"

source ./slob.conf

if [ -n "$ADMIN_SQLNET_SERVICE" ]
then
        export ADMIN_CONNECT_STRING="sys/${SYSDBA_PASSWD}@${ADMIN_SQLNET_SERVICE} as sysdba"
fi

sqlplus -L $ADMIN_CONNECT_STRING <<EOF
STARTUP FORCE PFILE=./${1}
EXIT;
EOF
