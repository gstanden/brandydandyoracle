-- DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
-- The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
-- all warranties of any kind, either express or implied, as to the software, including, but not limited to,
-- implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
-- rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
-- any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
-- circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
-- consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
-- user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
-- from the use or misuse of the software (including such damages incurred by third parties), or errors of
-- the software.                   


HOST ./mywait

-- SET SERVEROUTPUT OFF ;
SET SERVEROUTPUT ON   ;
SET VERIFY OFF;

create or replace directory mydir as '/tmp';

DECLARE
v_default_schema_number PLS_INTEGER := '&1';
v_update_pct PLS_INTEGER := '&2';
v_max_loop_iterations PLS_INTEGER := '&3';
v_seconds_to_run PLS_INTEGER := '&4';
v_scale PLS_INTEGER := '&5';
v_work_unit PLS_INTEGER := '&6' ;
v_redo_stress  VARCHAR2(12) := '&7';
v_shared_data_modulus PLS_INTEGER := '&8';

v_loop_cnt PLS_INTEGER := 0;
v_rowcnt PLS_INTEGER := 0;
v_updates PLS_INTEGER := 0;
v_selects PLS_INTEGER := 0;
v_random PLS_INTEGER;
v_tmp PLS_INTEGER;
v_now PLS_INTEGER;
v_brick_wall PLS_INTEGER;

v_begin_time PLS_INTEGER;
v_end_time PLS_INTEGER;
v_total_time PLS_INTEGER;
v_begin_cpu_tm PLS_INTEGER;
v_end_cpu_tm PLS_INTEGER;
v_total_cpu_tm PLS_INTEGER;

v_loop_control BOOLEAN := FALSE;
v_update_quota BOOLEAN := FALSE;
v_select_quota BOOLEAN := FALSE;
v_select_only_workload BOOLEAN := FALSE;
v_update_only_workload BOOLEAN := FALSE;
v_do_update BOOLEAN := FALSE;
v_do_shared_data BOOLEAN := FALSE;
v_stop_immediate BOOLEAN := FALSE;

v_seed VARCHAR2(50);
v_home_schema_str VARCHAR2(80) ;
v_scratch VARCHAR2(80) ;

v_cpu_pct NUMBER(6,3);

v_fd1 UTL_FILE.FILE_TYPE;

BEGIN

v_begin_cpu_tm := DBMS_UTILITY.GET_CPU_TIME();
v_begin_time := DBMS_UTILITY.GET_TIME();
v_now := v_begin_time ;
v_seconds_to_run := v_seconds_to_run * 100 ;
v_brick_wall := v_now + v_seconds_to_run ;

v_fd1 := UTL_FILE.FOPEN('MYDIR', 'db_stats.out', 'A');

v_home_schema_str := 'ALTER SESSION SET CURRENT_SCHEMA = user' || v_default_schema_number ;
EXECUTE IMMEDIATE v_home_schema_str; 

v_seed := TO_CHAR(SYSTIMESTAMP,'YYYYDDMMHH24MISSFFFF');
DBMS_RANDOM.seed (val => v_seed);

IF ( v_shared_data_modulus != 0 ) THEN
	v_do_shared_data := TRUE;
END IF;

IF ( v_max_loop_iterations > 0 ) THEN
	v_loop_control := TRUE ;
END IF;

IF ( v_update_pct = 0 ) THEN
	v_select_only_workload := TRUE;
END IF;	

IF ( v_update_pct = 100 ) THEN
	v_update_only_workload := TRUE;
END IF;	

v_update_quota := FALSE ;
v_select_quota := FALSE ;


while ( v_now < v_brick_wall AND v_stop_immediate != TRUE )  LOOP

	v_random := DBMS_RANDOM.VALUE(v_work_unit + 1, v_scale) ;

	IF  ( v_select_only_workload = TRUE ) THEN 
		-- handle case where user specified zero pct updates
		v_do_update := FALSE;
		v_update_quota := TRUE ;

	ELSE

		IF ( v_update_only_workload = TRUE ) THEN
			v_do_update := TRUE;
			v_update_quota := FALSE;
		ELSE			
			IF ( v_update_quota = FALSE ) THEN
				-- We are doing updates during this run and quota has not been met yet
				-- We still vacilate until update quota has been met
				v_do_update := FALSE;	

				v_tmp := MOD(v_random, 2);

				IF ( v_tmp = 0 ) THEN
					v_do_update := TRUE;
				END IF;
			ELSE
				-- UPDATE quota has been filled, force drain some SELECTs
				v_do_update := FALSE; 
			END IF;
		END IF;

	END IF;

	IF (v_do_shared_data = TRUE) THEN

		v_tmp := MOD(v_loop_cnt, v_shared_data_modulus);
		
		IF ( v_tmp = 0 ) THEN
			EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA = user0';
		ELSE
			EXECUTE IMMEDIATE v_home_schema_str;
		END IF;
	
	END IF;



	IF ( v_do_update = TRUE ) THEN
		v_updates := v_updates + 1;

		IF ( v_updates >= v_update_pct ) THEN
			v_update_quota := TRUE;	
		END IF;

		IF ( v_redo_stress = 'HEAVY' ) THEN

		UPDATE cf1 SET 
			c2  =  'AAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c3  =  'AAAAAAAABBBBBBBBAxAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c4  =  'AAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAA5ABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c5  =  'AAA0AAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBB4BBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c6  =  'AAAAAArABBBBBBBBAAAAAAAABBBBBBBBAAAAAAtABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBB3BAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c7  =  'AAA5AAAABBBBBBBtAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBB3BAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c8  =  'AAAAAAAABBB0BBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBB3BAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c9  =  'AAA0AAAABBBBBBBBAAAAAAAABrBBBBBBAAAAAArABBBBBBBBAAAAAAAABBB4BBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c10  = 'AAAAAArABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBB3BAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c11  = 'AAAAAAAABBBBBBBtAAAAAAAABBBBBBBBAAAAA-AABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBB3BAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c12  = 'AAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBB3BAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c13  = 'AAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAAB0BBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c14 =  'AAAAAAAABBBBBBBBAAAAA4AABBBBBBBBAAAAAAAABBB9BBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB',
			c15 =  'AAAAAAAABBBBBBBBAAAAAAAABB0BBBBBAAAAAAAABBBfBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB',
			c16 =  'AAAAAAAABBBBBBBBAAAAAAAABBBBBBBBrAAAAAAABBBBBBBBAA9AAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB',
			c17 =  'AAAAAAAABBBBBBBBAAA3AAAABBBBBBBBAAAAAAAABBBBBBBBAA-AAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB',
			c18 =  '3AAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB',
			c19 =  'A5AAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB',
			c20 =  'AAAAAAAABBBBBBBBAAAAAAAA0BBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBB0BBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB'
			WHERE  custid >  ( v_random - v_work_unit ) AND  ( custid < v_random);

		ELSE
        		UPDATE cf1 SET 
        		c2  = 'AAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBB',
			c20 = 'AAAAAAAABBBBBBBBAAAAAAAA0BBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBBBBBBAAAAAAAABBBB0BBBAAAAAAAABBBBBBBBAAAAAAAABBBBB3BBAAAAAAAABBBBBBBB'
			WHERE  custid >  ( v_random - v_work_unit ) AND  (custid < v_random);
			COMMIT;

		END IF;
	ELSE
		v_selects := v_selects + 1;		

		SELECT COUNT(c2) INTO v_rowcnt 
		FROM cf1 WHERE custid > ( v_random - v_work_unit ) AND  (custid < v_random);

	END IF ;

	IF ( v_select_only_workload = TRUE ) THEN
		NULL ;		
	ELSIF ( ( v_updates + v_selects ) >=  100 ) THEN
		v_update_quota := FALSE;
		v_select_quota := FALSE;	
		v_updates := 0;
		v_selects := 0;
	END IF;

	v_loop_cnt := v_loop_cnt + 1 ;
	
	IF ( v_loop_control = TRUE ) THEN
	
		IF ( v_loop_cnt >= v_max_loop_iterations ) THEN
			v_stop_immediate := TRUE ;
		END IF;

	END IF;

	v_now := DBMS_UTILITY.GET_TIME();

END LOOP;

v_now := DBMS_UTILITY.GET_TIME();
v_end_cpu_tm := DBMS_UTILITY.GET_CPU_TIME(); 
v_end_time := v_now ;

v_total_time := v_end_time - v_begin_time ;
v_total_cpu_tm := v_end_cpu_tm - v_begin_cpu_tm  ;
v_cpu_pct := ( v_total_cpu_tm / v_total_time ) * 100 ;
v_scratch := v_default_schema_number || '|' || v_total_time || '|' || v_total_cpu_tm || '|' || v_cpu_pct || '|' ;

UTL_FILE.PUT_LINE(v_fd1, v_scratch  );
UTL_FILE.FFLUSH(v_fd1); 
-- DBMS_LOCK.SLEEP(10);
END;
/
exit

