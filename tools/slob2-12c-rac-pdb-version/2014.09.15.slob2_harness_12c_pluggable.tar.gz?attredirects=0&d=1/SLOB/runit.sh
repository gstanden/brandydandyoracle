#!/bin/bash
# DISCLAIMER OF WARRANTIES AND LIMITATION OF LIABILITY
# The software is supplied "as is" and all use is at your own risk.  Peak Performance Systems disclaims
# all warranties of any kind, either express or implied, as to the software, including, but not limited to,
# implied warranties of fitness for a particular purpose, merchantability or non - infringement of proprietary
# rights.  Neither this agreement nor any documentation furnished under it is intended to express or imply
# any warranty that the operation of the software will be uninterrupted, timely, or error - free.  Under no
# circumstances shall Peak Performance Systems be liable to any user for direct, indirect, incidental,
# consequential, special, or exemplary damages, arising from or relating to this agreement, the software, or
# user#s use or misuse of the softwares.  Such limitation of liability shall apply whether the damages arise
# from the use or misuse of the software (including such damages incurred by third parties), or errors of
# the software.                         

function test_conn() {
local constring="$*"
local ret=""

sqlplus -L "$constring" <<EOF > /dev/null 2>&1
SELECT COUNT(*) from DUAL;
exit;
EOF

ret=$?
return $ret
}

function wait_pids() {
local pids="$*"

while ( ps -p $pids > /dev/null 2>&1 )
do
	sleep .5
done

}

function check_bom() {
local file=""

if [ ! -f ./misc/BOM ]
then
	echo "FATAL: ${0}: ${FUNCNAME}: No BOM file in ./misc. Incorrect SLOB file contents."
	return 1
fi

for file in `cat ./misc/BOM | xargs echo`
do
	if [ ! -f "$file" ]
	then
		echo "FATAL: ${0}: ${FUNCNAME}: Missing ${file}. Incorrect SLOB file contents."
		return 1
	fi
done

return 0

}


#---------- Main body

if ( ! check_bom )
then
	exit 1
fi

rm -f  awr.txt awr.*html  awr*.gz iostat.out vmstat.out mpstat.out /tmp/db_stats.out db_stats.out sqlplus.out 



if [ "$SLOB_DEBUG" = "TRUE" ]
then
	SQLPLUS_OUT_FILE="sqlplus.out"
else
	SQLPLUS_OUT_FILE="/dev/null"
fi


# Just in case user accidentally deleted lines in slob.conf:
UPDATE_PCT=${UPDATE_PCT:=10}
RUN_TIME=${RUN_TIME:=300}
WORK_LOOP=${WORK_LOOP:=0}
SCALE=${SCALE:=10000}
WORK_UNIT=${WORK_UNIT:=256}
REDO_STRESS=${REDO_STRESS:=HEAVY}
SHARED_DATA_MODULUS=${SHARED_DATA_MODULUS:=0}

ADMIN_SQLNET_SERVICE=${ADMIN_SQLNET_SERVICE:=''}
SQLNET_SERVICE_BASE=${SQLNET_SERVICE_BASE:=''}
SQLNET_SERVICE_MAX=${SQLNET_SERVICE_MAX:=0}
SYSDBA_PASSWD=${SYSDBA_PASSWD:=''}

DO_ROTOR=FALSE

export NON_ADMIN_CONNECT_STRING="PDBYOURS"
export ADMIN_CONNECT_STRING="/ as sysdba"

source ./slob.conf

if [[ "$#" != 1 || "$1" < 1 ]]
then
	echo "FATAL: "
	echo "${0}: Usage : ${0} <number of sessions to execute>"
	exit 1
fi

SESSIONS=$1
SQLPLUS_PIDS=""
MISC_PIDS=""
B=""
TM=""
CMD=""


if [ ! -x ./mywait ]
then
	echo ""
	echo "FATAL: ${0}: ./mywait executable not found."
	echo "FATAL: Please change directories to ./wait_kit and run make(1)."
	echo ""
	exit 1
fi


if [ -n "$ADMIN_SQLNET_SERVICE" ]
then
        export ADMIN_CONNECT_STRING="sys/${SYSDBA_PASSWD}@${ADMIN_SQLNET_SERVICE} as sysdba"
        export NON_ADMIN_CONNECT_STRING="@${SQLNET_SERVICE_BASE}"
fi


if [ -n "$SQLNET_SERVICE_BASE" ]
then
	if [ "$SQLNET_SERVICE_MAX" -gt 0 ]
	then
		echo "NOTIFY: SLOB sessions will connect round-robin from ${SQLNET_SERVICE_BASE}1 through ${SQLNET_SERVICE_BASE}${SQLNET_SERVICE_MAX}."
		DO_ROTOR=TRUE	
	else
		echo "NOTIFY: All SLOB sessions will connect to ${SQLNET_SERVICE_BASE}."
	fi
fi

echo "NOTIFY: 
UPDATE_PCT == $UPDATE_PCT
RUN_TIME == $RUN_TIME
WORK_LOOP == $WORK_LOOP
SCALE == $SCALE
WORK_UNIT == $WORK_UNIT
ADMIN_SQLNET_SERVICE == \"$ADMIN_SQLNET_SERVICE\"
ADMIN_CONNECT_STRING == \"$ADMIN_CONNECT_STRING\"
NON_ADMIN_CONNECT_STRING == \"$NON_ADMIN_CONNECT_STRING\"
SQLNET_SERVICE_MAX == \"$SQLNET_SERVICE_MAX\"
"
echo "NOTIFY: Testing SYSDBA connectivity to the instance to validate slob.conf settings."

if ( ! test_conn ${ADMIN_CONNECT_STRING} )
then

        echo "FATAL: ${0}: cannot connect to the instance."
	echo "FATAL: Connect string: \"${ADMIN_CONNECT_STRING}\""
        echo "FATAL: Please verify the instance and listener are running and the settings"
        echo "FATAL: in slob.conf are correct for your connectivity model."

        exit 1
fi


if [ "$DO_ROTOR" = "TRUE" ]
then
	echo "NOTIFY: Connections will rotor from ${NON_ADMIN_CONNECT_STRING}1 through ${NON_ADMIN_CONNECT_STRING}${SQLNET_SERVICE_MAX}"

	for (( i = 1 ; i <= $SQLNET_SERVICE_MAX ; i++ ))
	do
		CONNECT_STRING="@${NON_ADMIN_CONNECT_STRING}${i}"

		for U in ${SESSIONS} 0
		do
			echo "NOTIFY: Testing non-SYSDBA connectivity to ${CONNECT_STRING}"

			if ( !  test_conn "user${U}/user${U}${CONNECT_STRING}" )
			then
				echo "FATAL: Connect failure user${U}/user${U}${CONNECT_STRING}"
				exit 1
			fi
		done
	done

else
	echo "NOTIFY: Testing non-SYSDBA connectivity to instance."	

	for U in  ${SESSIONS} 0
	do

		if ( !  test_conn "user${U}/user${U}@${NON_ADMIN_CONNECT_STRING}" )
		then
			echo "FATAL: Connect failure user${U}/user${U}@${NON_ADMIN_CONNECT_STRING}"
			exit 1
		fi
	done

fi

echo "NOTIFY: Connectivity verified."

sqlplus $ADMIN_CONNECT_STRING @./misc/switchlog > /dev/null 2>&1

echo "NOTIFY: Setting up trigger mechanism."
./create_sem > /dev/null 2>&1

if [ -n "$NO_OS_PERF_DATA" ]
then
	:
else
	( iostat -xm 3 > iostat.out ) &
	MISC_PIDS="${MISC_PIDS} $!"
	( vmstat 3 > vmstat.out ) &
	MISC_PIDS="${MISC_PIDS} $!"
	( mpstat -P ALL 3  > mpstat.out ) &
	MISC_PIDS="${MISC_PIDS} $!"
fi

cnt=1
x=0
echo -ne "NOTIFY: Connecting users \c"

until [ $cnt -gt $SESSIONS ]
do
	echo -ne "${cnt} \c"
	CMD="sqlplus -s user${cnt}/user${cnt}@${NON_ADMIN_CONNECT_STRING}"
	SLOBARGS="$cnt $UPDATE_PCT $WORK_LOOP $RUN_TIME $SCALE $WORK_UNIT $REDO_STRESS $SHARED_DATA_MODULUS"
	( $CMD  @slob $SLOBARGS  >> $SQLPLUS_OUT_FILE 2>&1 ) &

	SQLPLUS_PIDS="${SQLPLUS_PIDS} $!"

	(( cnt = $cnt + 1 ))
	(( x = $cnt % 7 ))
	[[ $x -eq 0 ]] && sleep 1

done

echo ""
echo "NOTIFY: Pausing for $(( cnt / 6 )) seconds before triggering the test."

sleep $(( cnt / 6 ))

sqlplus -L $ADMIN_CONNECT_STRING   @awr/awr_snap > /dev/null

echo ""
echo "NOTIFY: Triggering the test."

B=$SECONDS
./trigger > /dev/null 2>&1

echo "NOTIFY: Test triggered. Executing"

wait_pids $SQLPLUS_PIDS

(( TM =  $SECONDS - $B ))

kill -9 $MISC_PIDS > /dev/null 2>&1 

echo "Tm $TM"

sqlplus -L $ADMIN_CONNECT_STRING @awr/awr_snap > /dev/null 2>&1
sqlplus -L $ADMIN_CONNECT_STRING  @awr/create_awr_report > /dev/null 2>&1
( sqlplus -L $ADMIN_CONNECT_STRING  @awr/create_awr_report_html > /dev/null 2>&1 ; gzip -f -9 awr.html > /dev/null 2>&1)
( sqlplus -L $ADMIN_CONNECT_STRING  @awr/create_awr_report_rac_html > /dev/null 2>&1 ; gzip -f -9 awr_rac.html > /dev/null 2>&1  )

mv /tmp/db_stats.out . > /dev/null 2>&1
echo "NOTIFY: SLOB test is complete."
exit 0
