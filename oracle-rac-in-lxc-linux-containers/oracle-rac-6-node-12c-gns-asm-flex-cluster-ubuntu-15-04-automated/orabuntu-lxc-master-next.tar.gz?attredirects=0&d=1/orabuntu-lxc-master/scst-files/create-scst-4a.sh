sudo mkdir /asm
cd /asm

# Create Target and Groups

  sudo scstadmin -add_target iqn.2015-08.org.vmem:w520.san.asm.luns -driver iscsi
  sudo scstadmin -add_group lxc1 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns
  sudo scstadmin -add_init iqn.2014-09.org.vmem1:oracle.asm.luns -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1
  sudo scstadmin -write_config /etc/scst.conf

  echo ''
  echo "======================================================"
  echo "Verify that target, groups, and initiators are added  "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  sudo scstadmin -list_group

  sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroup SYSTEMDG

  sudo fallocate -l 10G /asm/asm_systemdg_00.img
  sudo fallocate -l 10G /asm/asm_systemdg_01.img
  sudo fallocate -l 10G /asm/asm_systemdg_02.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for systemdg "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

ls -lrt /asm/asm_systemdg*

  sleep 10

# Create file-backed devices for LUNS for Oracle ASM diskgroups DATA and FRA

  sudo fallocate -l 30G /asm/asm_data1_00.img
  sudo fallocate -l 30G /asm/asm_data1_01.img
  sudo fallocate -l 30G /asm/asm_data1_02.img
  sudo fallocate -l 30G /asm/asm_fra1_00.img
  sudo fallocate -l 30G /asm/asm_fra1_01.img
  sudo fallocate -l 30G /asm/asm_fra1_02.img

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for data     "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

ls -lrt /asm/asm_data*

  sleep 10

  echo ''
  echo "======================================================"
  echo "Verify that device backing files created for fra      "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

ls -lrt /asm/asm_fra*

  sleep 10

# Open file-backed devices for Oracle ASM diskgroup SYSTEMDG

  sudo scstadmin -open_dev asm_systemdg_00 -handler vdisk_fileio -attributes filename=/asm/asm_systemdg_00.img
  sudo scstadmin -open_dev asm_systemdg_01 -handler vdisk_fileio -attributes filename=/asm/asm_systemdg_01.img
  sudo scstadmin -open_dev asm_systemdg_02 -handler vdisk_fileio -attributes filename=/asm/asm_systemdg_02.img

# Open file-backed devices for Oracle ASM diskgroups DATA and FRA

  sudo scstadmin -open_dev asm_data1_00    -handler vdisk_fileio -attributes filename=/asm/asm_data1_00.img
  sudo scstadmin -open_dev asm_data1_01    -handler vdisk_fileio -attributes filename=/asm/asm_data1_01.img
  sudo scstadmin -open_dev asm_data1_02    -handler vdisk_fileio -attributes filename=/asm/asm_data1_02.img
  sudo scstadmin -open_dev asm_fra1_00     -handler vdisk_fileio -attributes filename=/asm/asm_fra1_00.img
  sudo scstadmin -open_dev asm_fra1_01     -handler vdisk_fileio -attributes filename=/asm/asm_fra1_01.img
  sudo scstadmin -open_dev asm_fra1_02     -handler vdisk_fileio -attributes filename=/asm/asm_fra1_02.img

# Add LUNs for Oracle ASM diskgroup SYSTEMDG to SCST iscsi target

  sudo scstadmin -add_lun 0 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_00
  sudo scstadmin -add_lun 1 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_01
  sudo scstadmin -add_lun 2 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_systemdg_02

# Add LUNs for Oracle ASM diskgroups DATA and FRA to SCST iscsi target

  sudo scstadmin -add_lun 3 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_00
  sudo scstadmin -add_lun 4 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_01
  sudo scstadmin -add_lun 5 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_data1_02
  sudo scstadmin -add_lun 6 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_00
  sudo scstadmin -add_lun 7 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_01
  sudo scstadmin -add_lun 8 -driver iscsi -target iqn.2015-08.org.vmem:w520.san.asm.luns -group lxc1 -device asm_fra1_02

# Write SCST configuration to /etc/scst.conf file

  sudo scstadmin -write_config /etc/scst.conf

# Enable SCST target for access

  sudo scstadmin -enable_target iqn.2015-08.org.vmem:w520.san.asm.luns -driver iscsi
  sudo scstadmin -write_config /etc/scst.conf
  sleep 5

  echo "======================================================"
  echo "Answer y here...                                      "
  echo "======================================================"
  
  sudo scstadmin -set_drv_attr iscsi -attributes enabled=1
  sleep 5
  sudo scstadmin -write_config /etc/scst.conf

  echo ''
  echo "======================================================"
  echo "Verify that SCST SAN is fully configured and ready    "
  echo "Sleeping for 10 seconds...                            "
  echo "======================================================"
  echo ''

  sudo scstadmin -list_group

  sleep 10

