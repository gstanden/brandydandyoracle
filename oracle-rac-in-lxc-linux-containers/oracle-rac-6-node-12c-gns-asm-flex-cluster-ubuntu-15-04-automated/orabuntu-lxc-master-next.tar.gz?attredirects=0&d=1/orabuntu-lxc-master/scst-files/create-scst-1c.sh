#!/bin/bash

# GLS 20151126 Added function to get kernel version of running kernel to support linux 4.x kernels in Ubuntu Wily Werewolf etc.

function GetRunningKernelVersion {
uname -r | cut -f1-2 -d'.'
}
RunningKernelVersion=$(GetRunningKernelVersion)

# GLS 20151126 Added function to get kernel directory path for running kernel version to support linux 4.x and linux 3.x kernels etc.

function GetKernelDirectoryPath {
uname -a | cut -f3 -d' ' | cut -f1 -d'-' | sed 's/^/linux-/'
}
KernelDirectoryPath=$(GetKernelDirectoryPath)

cd ~/Downloads/$KernelDirectoryPath/

echo "=============================================================="
echo "About to write vars.scst...                                   "
echo "Sleeping 20 seconds...                                        "
echo "=============================================================="

sudo sed -i "s/Generic/SCST/" debian.master/control.d/vars.scst

echo ''
echo "=============================================================="
echo "About to write getabis for scst...                            "
echo "=============================================================="

sudo sed -i "/scst/!s/getall amd64 generic lowlatency/getall amd64 generic lowlatency scst/" debian.master/etc/getabis

echo ''
echo "=============================================================="
echo "About to write amd64.mk for scst...                           "
echo "=============================================================="

sudo sed -i "/scst/!s/generic lowlatency/generic lowlatency scst/" debian.master/rules.d/amd64.mk

echo ''
echo "=============================================================="
sudo cat debian.master/control.d/vars.scst
echo "=============================================================="
echo ''
sleep 5

echo ''
echo "=============================================================="
sudo cat debian.master/etc/getabis
echo "=============================================================="
echo ''
sleep 5

echo ''
echo "=============================================================="
sudo cat debian.master/rules.d/amd64.mk
echo "=============================================================="
echo ''
sleep 5

