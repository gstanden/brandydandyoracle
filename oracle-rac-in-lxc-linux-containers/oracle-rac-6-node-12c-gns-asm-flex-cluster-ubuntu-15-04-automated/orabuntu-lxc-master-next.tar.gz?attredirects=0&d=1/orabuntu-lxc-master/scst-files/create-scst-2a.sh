#!/bin/bash

sudo mkdir -p /dev/log
cd ~/Downloads

ls -l linux-image-* linux-headers*
sleep 10

sudo dpkg -i linux-image-* linux-headers*
sleep 5

sudo update-initramfs -u
sleep 5

function CheckContainersRunning {
sudo lxc-ls -f | grep RUNNING | sed 's/  */ /g' | cut -f1 -d' ' | sed 's/$/ /' | tr -d '\n' |  sed 's/^[ \t]*//;s/[ \t]*$//'
}
ContainersRunning=$(CheckContainersRunning)

for i in $ContainersRunning
do
sudo lxc-stop -n $i
sleep 5
done

echo ''
echo "==========================================="
echo "Verify LXC Containers are shutdown ...     "
echo "==========================================="

sudo lxc-ls -f

echo "==========================================="
echo "Rebooting in 5 seconds...                 "
echo "==========================================="

sleep 5

sudo reboot
