#! /bin/bash

# cd ~/Downloads
# sudo dpkg -i linux-image-* linux-headers*
# sleep 10
# sudo lxc-stop -n lxcora01
# sleep 5
# sudo lxc-stop -n lxcora02
# sleep 5
# sudo lxc-stop -n lxcora03
# sleep 5
# sudo lxc-stop -n lxcora04
# sleep 5
# sudo lxc-stop -n lxcora05
# sleep 5
# sudo lxc-stop -n lxcora06
# sleep 10
# echo ''
# sudo lxc-ls -f

cd ~/Downloads/scst
sudo make scst scst_install iscsi iscsi_install scstadm scstadm_install
cd ..
sleep 10
sudo systemctl enable scst.service

sudo service scst start
sudo service scst status

# sudo reboot

