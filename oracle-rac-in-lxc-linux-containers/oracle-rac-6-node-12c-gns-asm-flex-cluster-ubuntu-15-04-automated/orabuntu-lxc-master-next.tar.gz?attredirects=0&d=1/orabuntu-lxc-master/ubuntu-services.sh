clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-1.sh
clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-2a.sh
clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-2b.sh
clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-3a.sh
clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-3b.sh
clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-3c.sh 20
clear
~/Downloads/orabuntu-lxc-master/ubuntu-services-3d.sh

