#!/bin/bash

ping -c 1 google.com
if [ $? -ne 0 ]
then
echo ''
echo "============================================"
echo "Network is not up.  Script exiting.         "
echo "ping google.com must succeed                "
echo "Address network issues and retry script     "
echo "============================================"
echo ''
exit
fi

nslookup google.com
echo ''
ping -c 3 google.com

echo "=================================================="
echo "If network is not up, abort script and start up   "
echo "=================================================="

# # cd /
# cd ~/Downloads
# sudo service bind9 status
# sudo service isc-dhcp-server status
# nslookup lxcora01
# 
# echo "=================================================="
# echo "Verify all services running...                    "
# echo "Verify DHCP working...                            "
# echo "=================================================="
# sleep 10
# 
# sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/packages.sh
# sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/create_users.sh
# sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
# sudo sed -i 's/yum install/yum -y install/g' /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
# sudo cp -p ~/Downloads/install_grid.sh /var/lib/lxc/lxcora01/rootfs/root/install_grid.sh
# sudo cp -p ~/Downloads/lxc-services.sh /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
# sudo cp -p ~/Downloads/dhclient.conf /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf
# sudo chown root:root /var/lib/lxc/lxcora01/rootfs/root/install_grid.sh
# sudo chmod 755 /var/lib/lxc/lxcora01/rootfs/root/install_grid.sh
# sudo chown root:root /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
# sudo chmod 755 /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
# sudo chown root:root /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf
# sudo chmod 644 /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf
# 
# # sudo sed -i 's/BOOTPROTO=dhcp/BOOTPROTO=static/g' /var/lib/lxc/lxcora01/rootfs/etc/sysconfig/network-scripts/ifcfg-eth0
# 
# function GetMacAddr11 {
# sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -2 | tail -1 | cut -f2 -d'=' | sed 's/ //g'
# }
# 
# function GetMacAddr12 {
# sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
# }
# 
# sudo cp -p /var/lib/lxc/lxcora01/config /var/lib/lxc/lxcora01/config.original.bak
# OldMacAddr1=$(GetMacAddr11)
# sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -2 | tail -1
# sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora01/config
# NewMacAddr1=$(GetMacAddr12)
# sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -1
# sudo sed -i "s/$NewMacAddr1/$OldMacAddr1/g" /var/lib/lxc/lxcora01/config
# sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -1
# 
# sudo chmod 644 /var/lib/lxc/lxcora01/config

sudo lxc-start -n lxcora01

echo "============================================="
echo "Sleeping 30 seconds for interfaces to be up  "
echo "============================================="
echo ''
sleep 30
sudo lxc-ls -f

echo "============================================="
echo "Sleeping 30 seconds for interfaces to be up  "
echo "============================================="
echo ''

sleep 30
sudo lxc-ls -f
sudo lxc-stop -n lxcora01
sleep 10
sudo lxc-start -n lxcora01
echo ''
# echo "============================================="
# echo "Press <Enter> to accept ssh-keygen defaults"
# echo "============================================="
# echo ''
sleep 15
sudo lxc-ls -f
echo ''
echo "============================================="
echo "Check if lxcora01 running                    "
echo "Make sure IP on 10.207.39.x is assigned      "
echo "============================================="
# 
# ssh-keygen -t rsa
# cat  ~/.ssh/id_rsa.pub > ~/.ssh/authorized_keys
# sudo rm ~/.ssh/known_hosts
# echo "============================================="
# echo 'Password for following login is "root"'
# echo "============================================="
# echo ''
# echo "============================================="
# echo "Press <Enter> to accept ssh-keygen defaults"
# echo "============================================="
# echo ''
 
nslookup lxcora01

echo ''
echo "============================================="
echo "Check for ping output showing lxc host alive "
echo "Check for uname output showing login success "
echo "============================================="
echo ''
ping -c 3 lxcora01
echo ''
echo "============================================="
echo "Password is: root                            "
echo "============================================="

ssh root@lxcora01 uname -a
echo ''
sleep 15
# 
ssh root@lxcora01 ssh-keygen -t rsa
#
echo ''
echo "============================================="
echo "Setting up no-password ssh to container      " 
echo "============================================="
echo ''
sudo cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
sudo cp ~/.ssh/authorized_keys /var/lib/lxc/lxcora01/rootfs/root/.ssh/.

echo ''
echo "============================================="
echo "Testing passwordless-ssh for root user       "
echo "============================================="
echo ''

ssh root@lxcora01 uname -a
ping -c 3 lxcora01
sleep 15
sudo lxc-stop -n lxcora01
echo "============================================="
echo "After reboot run ubuntu-services-3a.sh        "
echo "Sleeping for 10 seconds...                   "
echo "============================================="
sleep 10
sudo lxc-ls -f
echo "============================================="
echo "Verify lxcora01 state is shutdown now        "
echo "Rebooting in 20 seconds...                   "
echo "============================================="
sleep 20
sudo reboot
# 
# # sudo tar -xvf /lxc-lxcora01.tar
