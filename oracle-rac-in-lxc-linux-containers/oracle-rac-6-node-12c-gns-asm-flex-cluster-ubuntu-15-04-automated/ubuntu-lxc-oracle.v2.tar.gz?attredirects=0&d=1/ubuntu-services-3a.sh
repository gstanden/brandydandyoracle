#!/bin/bash

# cd /

ping -c 1 google.com
if [ $? -ne 0 ]
then
echo ''
echo "============================================"
echo "Network is not up.  Script exiting.         "
echo "ping google.com must succeed                "
echo "Address network issues and retry script     "
echo "============================================"
echo ''
exit
fi

sudo service bind9 status
sudo service isc-dhcp-server status
nslookup lxcora01

echo "=================================================="
echo "Verify all services running...                    "
echo "Verify DHCP working...                            "
echo "=================================================="
sleep 10

cd ~/Downloads
sudo lxc-start -n lxcora01
sleep 20
sudo lxc-ls -f
sleep 30
echo ''
echo "=================================================="
echo "Verify no-password ssh working to lxcora01        "
echo "=================================================="

ssh root@lxcora01 uname -a
echo ''
sudo lxc-stop -n lxcora01
echo ''
echo "================================================"
echo "Sleeping 15 seconds...Verify lxcora01 stopped   "
echo "Terminate script if lxcora01 is not stopped     "
echo "================================================"
echo ''
sudo lxc-ls -f
sleep 15

sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/ssh/sshd_config
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/sysctl.conf
# sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/.bashrc
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/rc.local
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/sysconfig/ntpd
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/fstab
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/security/limits.conf
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/create_directories.sh
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/hugepages_setting.sh
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/nsswitch.conf
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/ntp.conf
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/selinux/config
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/sysconfig/network
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/etc/selinux/config
# sudo cp -p /var/lib/lxc/lxcora01/rootfs/home/grid/grid/rpm/cvuqdisk-1.0.9-1.rpm /var/lib/lxc/lxcora01/rootfs/root/.

sudo lxc-stop -n lxcora01
sleep 15
sudo lxc-ls -f

# sudo lxc-start -n lxcora01
# echo "================================================"
# echo "Sleeping 15 seconds...Verify lxcora01 running   "
# echo "================================================"
# echo ''
# sudo lxc-ls -f
# sleep 15

# ssh root@lxcora01 uname -a
# echo "================================================"
# echo "Sleeping 15 seconds...Check lxcora01 login ok   "
# echo "================================================"
# echo ''
# sleep 15
# ssh root@lxcora01 /root/packages.sh
# ssh root@lxcora01 /root/create_users.sh
# ssh root@lxcora01 /root/lxc-services.sh
# ssh root@lxcora01 /root/install_grid.sh
# sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/home/grid/grid/rpm/cvuqdisk-1.0.9-1.rpm
# ssh root@lxcora01 rpm -Uvh /home/grid/grid/rpm/cvuqdisk-1.0.9-1.rpm
# 
# # sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/home/grid/.bashrc
# sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/home/oracle/.bashrc

# sudo lxc-stop -n lxcora01
# sudo lxc-ls -f
# echo "================================================"
# echo "Sleeping 15 seconds...Check lxcora01 shutdown   "
# echo "================================================"
# echo ''
# sleep 15

# sudo lxc-clone -o lxcora01 -n lxcora02
# sleep 5
# sudo lxc-clone -o lxcora01 -n lxcora03
# sleep 5
# sudo lxc-clone -o lxcora01 -n lxcora04
# sleep 5
# sudo lxc-clone -o lxcora01 -n lxcora05
# sleep 5
# sudo lxc-clone -o lxcora01 -n lxcora06
# sleep 5
# sudo lxc-clone -o lxcora01 -n lxcora00

# function GetMacAddr2 {
# sudo grep hwaddr /var/lib/lxc/lxcora02/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
# }

# function GetMacAddr3 {
# sudo grep hwaddr /var/lib/lxc/lxcora03/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
# }

# function GetMacAddr4 {
# sudo grep hwaddr /var/lib/lxc/lxcora04/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
# }

# function GetMacAddr5 {
# sudo grep hwaddr /var/lib/lxc/lxcora05/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
# }

# function GetMacAddr6 {
# sudo grep hwaddr /var/lib/lxc/lxcora06/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
# }

# OldMacAddr2=$(GetMacAddr2)
# sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora02/config
# NewMacAddr2=$(GetMacAddr2)
# sudo sed -i "s/$NewMacAddr2/$OldMacAddr2/g" /var/lib/lxc/lxcora02/config
# sudo chmod 644 /var/lib/lxc/lxcora02/config

# OldMacAddr3=$(GetMacAddr3)
# sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora03/config
# NewMacAddr3=$(GetMacAddr3)
# sudo sed -i "s/$NewMacAddr3/$OldMacAddr3/g" /var/lib/lxc/lxcora03/config
# sudo chmod 644 /var/lib/lxc/lxcora03/config

# OldMacAddr4=$(GetMacAddr4)
# sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora04/config
# NewMacAddr4=$(GetMacAddr4)
# sudo sed -i "s/$NewMacAddr4/$OldMacAddr4/g" /var/lib/lxc/lxcora04/config
# sudo chmod 644 /var/lib/lxc/lxcora04/config

# OldMacAddr5=$(GetMacAddr5)
# sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora05/config
# NewMacAddr5=$(GetMacAddr5)
# sudo sed -i "s/$NewMacAddr5/$OldMacAddr5/g" /var/lib/lxc/lxcora05/config
# sudo chmod 644 /var/lib/lxc/lxcora05/config

# OldMacAddr6=$(GetMacAddr6)
# sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora06/config
# NewMacAddr6=$(GetMacAddr6)
# sudo sed -i "s/$NewMacAddr6/$OldMacAddr6/g" /var/lib/lxc/lxcora06/config
# sudo chmod 644 /var/lib/lxc/lxcora06/config

# # Next step has authorized_keys files for each Container.
# # This is not used because Oracle can configure this automatically in 12c
# # sudo tar -xvf lxc-lxcora0x.tar
# sudo chown bind:bind /var/lib/bind/fwd.*
# sudo chown bind:bind /var/lib/bind/rev.*
# # sudo chown root:root /etc/dhcp/dhcpd.conf /etc/dhcp/dhclient.conf
# # See if default /etc/network/interfaces could be used instead
# # sudo chmod 755 /etc/network/interfaces
# # sudo chown root:root /etc/network/interfaces
# if [ ! -e ~/Networking ]
# then
# mkdir ~/Networking
# fi
# cd ~/Networking
# ./crt_links.sh
# sudo lxc-start -n lxcora01
# sleep 15
# nslookup lxcora01
# sudo lxc-start -n lxcora02
# sleep 15
# nslookup lxcora02
# sudo lxc-start -n lxcora03
# sleep 15
# nslookup lxcora03
# sudo lxc-start -n lxcora04
# sleep 15
# nslookup lxcora04
# sudo lxc-start -n lxcora05
# sleep 15
# nslookup lxcora05
# sudo lxc-start -n lxcora06
# sleep 15
# nslookup lxcora06
# sleep 10
# sudo lxc-ls -f
# echo "================================================"
# echo "Sleeping 15 seconds...Verify containers running "
# echo "Verify all containers are on 10.207.39.x        "
# echo "================================================"
# echo ''
# sleep 25
