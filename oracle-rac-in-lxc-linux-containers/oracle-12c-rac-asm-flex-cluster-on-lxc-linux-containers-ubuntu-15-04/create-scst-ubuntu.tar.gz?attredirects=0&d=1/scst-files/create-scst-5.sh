mv ~/Downloads/scst-files/multipath.conf /etc/multipath.conf
mv ~/Downloads/scst-files/multipath.conf.readme /etc/multipath.conf.readme
sudo service multipath-tools start
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.41.1 --login
sudo iscsiadm --mode node --targetname iqn.2015-08.org.vmem:w520.san.asm.luns   --portal 10.207.40.1 --login
ls -lrt /dev/mapper


