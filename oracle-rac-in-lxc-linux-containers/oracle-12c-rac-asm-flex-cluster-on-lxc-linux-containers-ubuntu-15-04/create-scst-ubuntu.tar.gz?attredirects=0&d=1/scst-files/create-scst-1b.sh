cd ~/Downloads/linux-3.19.0/
sudo cat debian.master/control.d/vars.generic | sed 's/Generic/SCST/' > debian.master/control.d/vars.scst
sudo cat debian.master/etc/getabis | sed 's/getall amd64 generic lowlatency/getall amd64 generic lowlatency scst/' > debian.master/etc/getabis.scst
sudo mv debian.master/etc/getabis.scst debian.master/etc/getabis
sudo cat debian.master/rules.d/amd64.mk | sed 's/generic lowlatency/generic lowlatency scst/' > debian.master/rules.d/amd64.mk.scst
sudo mv debian.master/rules.d/amd64.mk.scst debian.master/rules.d/amd64.mk
