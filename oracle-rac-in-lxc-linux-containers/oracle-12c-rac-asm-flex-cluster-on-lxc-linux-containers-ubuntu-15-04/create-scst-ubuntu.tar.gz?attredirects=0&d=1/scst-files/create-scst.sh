sudo ./create-scst-1a.sh
sudo ./create-scst-1b.sh
sudo ./create-scst-1c.sh
sudo ./create-scst-2.sh
sudo ./create-scst-3.sh
sudo ./create-scst-4.sh
sudo ./create-multipath.sh
sudo ./create-scst-5.sh
