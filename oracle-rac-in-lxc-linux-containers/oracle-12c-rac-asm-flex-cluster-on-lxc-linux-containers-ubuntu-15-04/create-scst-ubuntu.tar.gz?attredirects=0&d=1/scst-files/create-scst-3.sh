cd ~/Downloads/scst
sudo modprobe scst
sudo modprobe scst_vdisk
sudo modprobe iscsi-scst
sudo iscsi-scstd
