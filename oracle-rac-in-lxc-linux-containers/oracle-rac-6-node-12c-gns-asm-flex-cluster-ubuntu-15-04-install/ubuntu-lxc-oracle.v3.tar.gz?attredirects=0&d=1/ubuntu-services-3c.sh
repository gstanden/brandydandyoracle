#!/bin/bash

echo "============================================"
echo "Usage: ./ubuntu-services-3c.sh NumCon       "
echo "============================================"

echo "============================================"
echo "This script is re-runnable.                 "
echo "============================================"

echo "============================================"
echo "NumCon is the number of RAC nodes           "
echo "NumCon (small integer)                      "
echo "NumCon defaults to value '2'                "
echo "============================================"

if [ -z $1 ]
then
NumCon=2
else
NumCon=$1
fi

echo ''
echo "============================================"
echo "Number of LXC Container RAC Nodes = $NumCon "
echo "============================================"
echo ''

echo "============================================"
echo "If wrong number of desired RAC nodes, then  "
echo "<ctrl>+c and restart script to set          "
echo "Sleeping 15 seconds...                      "
echo "============================================"

sleep 15

echo ''
echo "============================================"
echo "This script creates oracle-ready lxc clones "
echo "for oracle-ready RAC container nodes        "
echo "============================================"

sudo lxc-start -n lxcora01 > /dev/null 2>&1

echo ''
echo "============================================"
echo "Checking status of bind9 DNS...             "
echo "============================================"
echo ''
sudo service bind9 status
echo '' 
sleep 5

echo ''
echo "============================================"
echo "Checking status of isc-dhcp-server DHCP...  "
echo "============================================"
echo ''
sudo service isc-dhcp-server status
echo ''
echo "============================================"
echo "Services checks completed.                  "
echo "============================================"
sleep 5

clear
echo "============================================"
echo "Begin google.com ping test...               "
echo "============================================"
echo ''

ping -c 3 google.com

echo ''
echo "============================================"
echo "End google.com ping test                    "
echo "============================================"
echo ''

sleep 3

function CheckNetworkUp {
ping -c 1 google.com | grep 'packet loss' | cut -f1 -d'%' | cut -f6 -d' ' | sed 's/^[ \t]*//;s/[ \t]*$//'
}
NetworkUp=$(CheckNetworkUp)
if [ "$NetworkUp" -ne 0 ]
then
echo ''
echo "============================================"
echo "Destination google.com is not pingable      "
echo "Address network issues and retry script     "
echo "Script exiting                              "
echo "============================================"
echo ''
exit
fi

function CheckContainerUp {
sudo lxc-ls -f | grep lxcora01 | sed 's/  */ /g' | grep RUNNING  | cut -f2 -d' '
}
ContainerUp=$(CheckContainerUp)

if [ $ContainerUp != 'RUNNING' ]
then
sudo lxc-stop  -n lxcora01
sudo lxc-start -n lxcora01
fi

function CheckPublicIP {
sudo lxc-ls -f | sed 's/  */ /g' | grep RUNNING | cut -f3 -d' ' | sed 's/,//' | cut -f1-3 -d'.' | sed 's/\.//g'
}
PublicIP=$(CheckPublicIP)

clear

echo "============================================"
echo "Bringing up public ip on lxcora01...        "
echo "============================================"
echo ''

sleep 5

while [ "$PublicIP" -ne 1020739 ]
do
PublicIP=$(CheckPublicIP)
echo "Waiting for lxcora01 Public IP to come up..."
sudo lxc-ls -f | sed 's/  */ /g' | grep RUNNING | cut -f3 -d' ' | sed 's/,//'
sleep 1
done

echo ''
echo "===========================================" 
echo "Public IP is up on lxcora01                "
echo ''
sudo lxc-ls -f
echo ''
echo "==========================================="
echo "Container Up.                              "
echo "==========================================="

sleep 3
clear

echo "==========================================="
echo "Verify no-password ssh working to lxcora01 "
echo "==========================================="
echo ''

ssh root@lxcora01 uname -a

echo ''
echo "==========================================="
echo "Verification of no-password ssh completed. "
echo "==========================================="

sleep 4

clear

echo "==========================================="
echo "Stopping lxcora01 container...             "
echo "==========================================="
echo ''
sudo lxc-stop -n lxcora01

while [ "$ContainerUp" = 'RUNNING' ]
do
sleep 1
sudo lxc-ls -f
ContainerUp=$(CheckContainerUp)
echo ''
echo $ContainerUp
done
echo ''
echo "==========================================="
echo "Container stopped.                         "
echo "==========================================="

sleep 3

clear

echo "!!! WARNING !!!"

echo "==========================================="
echo "Destruction of cloned containers ( Y / N ) "
echo "==========================================="

function CheckClonedContainersExist {
sudo ls /var/lib/lxc | more | tr -d '\n' | sed 's/lxcora01 //'
}
ClonedContainersExist=$(CheckClonedContainersExist)

echo ''
echo "ClonedContainersExist= $ClonedContainersExist"
echo ''

sleep 10

echo "Existing containers in the set { $ClonedContainersExist } have been found."
echo "These containers match the names of containers that are about to be created."
echo "Please answer Y to destroy the existing containers or N to keep them"

echo "!!! WARNING:  ANSWERING Y WILL DESTROY EXISTING CONTAINERS !!!"

echo "Destroy existing containers?  [ Y | N ]:"
read input_variable
echo "You entered: $input_variable"

echo "<ctrl>+c to exit program and abort container destruction"
echo "sleeping for 20 seconds..."

sleep 20

for j in $ClonedContainersExist
do
echo $j
echo "<ctrl>+c to exit"

if [ $input_variable = 'N' ]
then
echo "sudo lxc-destroy -n $j"
fi

if [ $input_variable = 'Y' ]
then
sudo lxc-destroy -n $j
fi

done
 
echo "==========================================="
echo "Cloning lxcora01 to $NumCon containers     "
echo "==========================================="

i=2
while [ $i -le "$NumCon" ]
do
sudo lxc-clone -o lxcora01 -n lxcora0$i
i=$((i+1))
sleep 5
done

echo "==========================================="
echo "Container cloning completed.               "
echo "==========================================="

sleep 3

clear

echo "==========================================="
echo "Cloning lxcora00 for reference container   "
echo "==========================================="
echo ''
 
sudo lxc-clone -o lxcora01 -n lxcora00
sleep 5

echo "=========================================="
echo "Container lxcora00 clone completed.       " 
echo "=========================================="
echo ''

sleep 3

clear

echo "=========================================="
echo "Performing LXC and MAC Address Setups...  "
echo "=========================================="
echo ''

function GetMacAddr2 {
sudo grep hwaddr /var/lib/lxc/lxcora02/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
}
 
function GetMacAddr3 {
sudo grep hwaddr /var/lib/lxc/lxcora03/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
}
 
function GetMacAddr4 {
sudo grep hwaddr /var/lib/lxc/lxcora04/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
}
 
function GetMacAddr5 {
sudo grep hwaddr /var/lib/lxc/lxcora05/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
}
 
function GetMacAddr6 {
sudo grep hwaddr /var/lib/lxc/lxcora06/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
}
 
OldMacAddr2=$(GetMacAddr2)
sudo tar -vP --extract --file=lxc-config.tar /var/lib/lxc/lxcora02/config
NewMacAddr2=$(GetMacAddr2)
sudo sed -i "s/$NewMacAddr2/$OldMacAddr2/g" /var/lib/lxc/lxcora02/config
sudo chmod 644 /var/lib/lxc/lxcora02/config

OldMacAddr3=$(GetMacAddr3)
sudo tar -vP --extract --file=lxc-config.tar /var/lib/lxc/lxcora03/config
NewMacAddr3=$(GetMacAddr3)
sudo sed -i "s/$NewMacAddr3/$OldMacAddr3/g" /var/lib/lxc/lxcora03/config
sudo chmod 644 /var/lib/lxc/lxcora03/config
 
OldMacAddr4=$(GetMacAddr4)
sudo tar -vP --extract --file=lxc-config.tar /var/lib/lxc/lxcora04/config
NewMacAddr4=$(GetMacAddr4)
sudo sed -i "s/$NewMacAddr4/$OldMacAddr4/g" /var/lib/lxc/lxcora04/config
sudo chmod 644 /var/lib/lxc/lxcora04/config
 
OldMacAddr5=$(GetMacAddr5)
sudo tar -vP --extract --file=lxc-config.tar /var/lib/lxc/lxcora05/config
NewMacAddr5=$(GetMacAddr5)
sudo sed -i "s/$NewMacAddr5/$OldMacAddr5/g" /var/lib/lxc/lxcora05/config
sudo chmod 644 /var/lib/lxc/lxcora05/config
 
OldMacAddr6=$(GetMacAddr6)
sudo tar -vP --extract --file=lxc-config.tar /var/lib/lxc/lxcora06/config
NewMacAddr6=$(GetMacAddr6)
sudo sed -i "s/$NewMacAddr6/$OldMacAddr6/g" /var/lib/lxc/lxcora06/config
sudo chmod 644 /var/lib/lxc/lxcora06/config
 
echo "=========================================="
echo "LXC and MAC address setups completed.     "
echo "=========================================="

sleep 3

clear

echo "================================================"
echo "Now run ubuntu-services-3d.sh                   "
echo "================================================"
