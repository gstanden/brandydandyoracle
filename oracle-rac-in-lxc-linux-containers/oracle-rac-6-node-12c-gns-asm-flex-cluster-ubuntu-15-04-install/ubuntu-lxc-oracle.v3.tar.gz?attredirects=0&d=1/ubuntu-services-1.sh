#!/bin/bash

echo ''
echo "============================================"
echo "Verify network up...."
echo "============================================"
echo ''

ping -c 1 google.com
if [ $? -ne 0 ]
then
echo ''
echo "============================================"
echo "Network is not up.  Script exiting.         "
echo "ping google.com must succeed                "
echo "Address network issues and retry script     "
echo "============================================"
echo ''
exit
fi

sudo apt-get install -y synaptic
sudo apt-get install -y cpu-checker
sudo apt-get install -y lxc
sudo apt-get install -y uml-utilities
sudo apt-get install -y openvswitch-switch
sudo apt-get install -y openvswitch-common
sudo apt-get install -y openvswitch-controller
sudo apt-get install -y bind9
sudo apt-get install -y bind9utils
sudo apt-get install -y isc-dhcp-server
sudo apt-get install -y apparmor-utils
sudo apt-get install -y openssh-server
sudo apt-get install -y uuid
# sudo apt-get install -y qemu-kvm
# sudo apt-get install -y libvirt-bin
# sudo apt-get install -y virt-manager
sudo apt-get install -y rpm
sudo apt-get install -y yum
sudo apt-get install -y hugepages
# sudo apt-get install -y nfs-kernel-server
# sudo apt-get install -y nfs-common portmap
sudo apt-get install -y multipath-tools
sudo apt-get install -y open-iscsi 
sudo apt-get install -y multipath-tools 
sudo apt-get install -y ntp
sudo aa-complain /usr/bin/lxc-start
# sudo service bind9 stop
# sudo service isc-dhcp-server stop
# sudo service multipath-tools stop
sudo lxc-create -t oracle -n lxcora01
# Backup existing files before untar of updated files.
sudo ubuntu-host-backup.sh
sudo tar -P -xvf ubuntu-host.tar
# sudo ~/OpenvSwitch/del-bridges.sh
echo "============================================="
echo "Rebooting the Ubuntu host...                 "
echo "After reboot run ubuntu-services-2a.sh       "
echo "Sleeping for 10 seconds before reboot...     "
echo "============================================="
sleep 10
sudo reboot
