#!/bin/bash

ping -c 1 google.com
if [ $? -ne 0 ]
then
echo ''
echo "============================================"
echo "Network is not up.  Script exiting.         "
echo "ping google.com must succeed                "
echo "Address network issues and retry script     "
echo "============================================"
echo ''
exit
fi

echo ''
echo "=================================================="
echo " nslookup and ping output for google.com below... "
echo "=================================================="
echo ''

nslookup google.com
echo ''
ping -c 3 google.com

echo ''
echo "=================================================="
echo "If network is not up, abort script and start up   "
echo "=================================================="
echo ''

# cd /
cd ~/Downloads

echo ''
echo "=================================================="
echo "Test bind9 and DHCP                               "
echo "=================================================="
echo ''

echo ''
echo "=================================================="
echo "Verify bind9 status good below                    "
echo "=================================================="
echo ''

sudo service bind9 status

sleep 10
 
echo ''
echo "=================================================="
echo "Verify isc-dhcp-server status good below          "
echo "=================================================="
echo ''

sudo service isc-dhcp-server status

echo ''
echo "=================================================="
echo "Verify nslookups good below          "
echo "=================================================="
echo ''

nslookup vmem1
nslookup lxc1-gns-vip
nslookup 10.207.39.1
nslookup 10.207.39.3

nslookup lxcora01
if [ $? -ne 0 ]
then
echo ''
echo "=================================================="
echo "If  nslookup for lxcora01 failed script will exit "
echo "Fix nslookup for lxcora01 and retry script        "
echo "=================================================="
echo ''
exit
fi

echo "=================================================="
echo "Extracting lxcora01 container-specific files...   "
echo "=================================================="

sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/packages.sh
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/create_users.sh
sudo tar -P --extract --file=lxc-lxcora01.tar /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
sudo sed -i 's/yum install/yum -y install/g' /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
sudo cp -p ~/Downloads/install_grid.sh /var/lib/lxc/lxcora01/rootfs/root/install_grid.sh
sudo cp -p ~/Downloads/lxc-services.sh /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
sudo cp -p ~/Downloads/dhclient.conf /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf
sudo chown root:root /var/lib/lxc/lxcora01/rootfs/root/install_grid.sh
sudo chmod 755 /var/lib/lxc/lxcora01/rootfs/root/install_grid.sh
sudo chown root:root /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
sudo chmod 755 /var/lib/lxc/lxcora01/rootfs/root/lxc-services.sh
sudo chown root:root /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf
sudo chmod 644 /var/lib/lxc/lxcora01/rootfs/etc/dhcp/dhclient.conf

sleep 10

# sudo sed -i 's/BOOTPROTO=dhcp/BOOTPROTO=static/g' /var/lib/lxc/lxcora01/rootfs/etc/sysconfig/network-scripts/ifcfg-eth0

function GetMacAddr11 {
sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -2 | tail -1 | cut -f2 -d'=' | sed 's/ //g'
}

function GetMacAddr12 {
sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -1 | cut -f2 -d'=' | sed 's/ //g'
}

sudo cp -p /var/lib/lxc/lxcora01/config /var/lib/lxc/lxcora01/config.original.bak
OldMacAddr1=$(GetMacAddr11)
sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -2 | tail -1
sudo tar -P --extract --file=lxc-config.tar /var/lib/lxc/lxcora01/config
NewMacAddr1=$(GetMacAddr12)
sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -1
sudo sed -i "s/$NewMacAddr1/$OldMacAddr1/g" /var/lib/lxc/lxcora01/config
sudo grep hwaddr /var/lib/lxc/lxcora01/config | head -1

sudo chmod 644 /var/lib/lxc/lxcora01/config
sudo lxc-start -n lxcora01
echo "============================================="
echo "Press <Enter> to accept ssh-keygen defaults"
echo "============================================="
echo ''
sudo lxc-ls -f
echo "============================================="
echo "Check if lxcora01 running                    "
echo "Check if 10.207.39.x IP is up                "
echo "============================================="
sleep 30
sudo lxc-ls -f

echo ''
echo "============================================="
echo "Press <Enter> to accept ssh-keygen defaults"
echo "============================================="
echo ''

ssh-keygen -t rsa
cat  ~/.ssh/id_rsa.pub > ~/.ssh/authorized_keys

if [ -e ~/.ssh/known_hosts ]
then
sudo rm ~/.ssh/known_hosts
fi

echo "============================================="
echo 'Password for lxcora01 root login is "root"   '
echo "============================================="
echo ''

nslookup lxcora01
ping -c 3 lxcora01
sleep 10

ssh root@lxcora01 uname -a

# sudo cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
# sudo cp ~/.ssh/authorized_keys /var/lib/lxc/lxcora01/rootfs/root/.ssh/.
# sudo lxc-stop -n lxcora01
echo "============================================="
echo "Rebooting the Ubuntu host...                 "
echo "After reboot run ubuntu-services-2b.sh       "
echo "Sleeping for 20 seconds...                   "
echo "============================================="
sleep 20
sudo lxc-ls -f 
echo "============================================="
echo "lxcora01 should be shutdown now.             "
echo "Ubuntu host will reboot in 10 seconds...     "
echo "============================================="
sudo lxc-ls -f 
sleep 20
sudo reboot

# sudo tar -xvf /lxc-lxcora01.tar
