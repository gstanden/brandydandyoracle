sudo service bind9 status
sudo service isc-dhcp-server status
nslookup lxcora01
nslookup lxcora02
nslookup lxcora03
nslookup lxcora04
nslookup lxcora05
nslookup lxcora06
nslookup lxcora01.vmem.org
nslookup lxcora02.vmem.org
nslookup lxcora03.vmem.org
nslookup lxcora04.vmem.org
nslookup lxcora05.vmem.org
nslookup lxcora06.vmem.org
nslookup vmem1
nslookup vmem1.vmem.org
nslookup oracle651
nslookup oracle651.vmem.org
nslookup vmem2
nslookup vmem2.vmem.org
nslookup 10.207.39.110
nslookup 10.207.39.111
nslookup 10.207.39.112
nslookup 10.207.39.113
nslookup 10.207.39.114
nslookup 10.207.39.115
sudo service bind9 status
sudo service isc-dhcp-server status

