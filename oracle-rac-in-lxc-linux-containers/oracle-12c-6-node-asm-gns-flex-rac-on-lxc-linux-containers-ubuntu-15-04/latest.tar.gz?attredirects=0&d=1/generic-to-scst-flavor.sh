sudo cp -p /root/config.flavour.scst /home/gstanden/Downloads/linux-3.19.0/debian.master/config/amd64/config.flavour.scst
sudo cp -p /root/scst /home/gstanden/Downloads/linux-3.19.0/debian.master/abi/3.19.0-24.25/amd64/scst
sudo cp -p /root/scst.modules /home/gstanden/Downloads/linux-3.19.0/debian.master/abi/3.19.0-24.25/amd64/scst.modules
sudo cp -p /root/vars.scst /home/gstanden/Downloads/linux-3.19.0/debian.master/control.d/vars.scst
