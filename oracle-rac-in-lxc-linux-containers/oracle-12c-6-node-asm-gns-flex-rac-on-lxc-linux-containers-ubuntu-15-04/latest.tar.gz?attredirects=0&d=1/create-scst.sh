sudo gpg --keyserver keyserver.ubuntu.com --recv-keys B1CDE58F
sudo svn co https://scst.svn.sourceforge.net/svnroot/scst/trunk scst
cd scst
sudo scripts/generate-kernel-patch 3.19 > ../scst.patch
cd ..
sudo apt-get source linux-image-$(uname -r)
sudo apt-get build-dep linux-image-$(uname -r)
sudo apt-get install libncurses5-dev
cd linux-3.19.0/
sudo patch -Np1 -i ../scst.patch
sudo chmod a+x debian/scripts/*
sudo chmod a+x debian/scripts/misc/*
/home/gstanden/Downloads/generic-to-scst-flavor.sh
sudo fakeroot debian/rules clean
sudo debian/rules updateconfigs
sudo debian/rules editconfigs

